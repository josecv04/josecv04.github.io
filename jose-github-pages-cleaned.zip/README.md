# Jose Resume Site (Recruiter-Optimized)

## Deploy
Repo → Settings → Pages → Deploy from branch `main` / folder `/ (root)`.

## Add visuals (recommended)
Put images in `assets/` and name them:
- `legoeeg.png`
- `microneedle.png`
- `robocar.png`
- `ecg-epg.png`

Then replace the placeholder boxes with `<img>` tags (or I can do it for you after you upload images).
